#include <stdio.h>
#include <cs50.h>

int main(void)
{
    // Get users Name, and greet
    
    string name = get_string("Whats Your name?\n");
    
    printf("Hello, %s\n", name);
}